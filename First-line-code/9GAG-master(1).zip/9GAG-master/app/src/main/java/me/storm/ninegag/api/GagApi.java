package me.storm.ninegag.api;

/**
 * Created by storm on 14-3-25.
 */
public class GagApi {
    private static final String HOST = "http://infinigag.k3min.eu";

    public static final String LIST = HOST + "/%1$s/%2$s";
}
