package com.wuchao.latte.net;

/**
 * @author: wuchao
 * @date: 2017/10/23 22:51
 * @desciption:
 */

public enum HttpMethod {
    GET,
    POST,
    POST_RAW,
    PUT,
    PUT_RAW,
    DELETE,
    UPLOAD
}
