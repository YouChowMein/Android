package com.wuchao.latte.ui.recycler;

/**
 * @author: wuchao
 * @date: 2017/12/6 21:59
 * @desciption:
 */

public enum MultipleFields {
    ITEM_TYPE,
    TITLE,
    TEXT,
    IMAGE_URL,
    BANNERS,
    SPAN_SIZE,
    ID,
    NAME,
    TAG
}
