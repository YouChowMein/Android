package com.wuchao.latte.util.callback;

/**
 * @author: wuchao
 * @date: 2018/1/7 17:02
 * @desciption:
 */

public enum CallbackType {
    ON_CROP,
    TAG_OPEN_PUSH,
    TAG_STOP_PUSH,
    ON_SCAN
}
