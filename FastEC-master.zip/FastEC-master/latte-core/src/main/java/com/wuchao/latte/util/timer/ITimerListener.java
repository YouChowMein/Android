package com.wuchao.latte.util.timer;

/**
 * @author: wuchao
 * @date: 2017/11/15 21:32
 * @desciption:
 */

public interface ITimerListener {
    void onTimer();
}
