package com.wuchao.latte.net.rx;

/**
 * @author: wuchao
 * @date: 2018/1/22 16:58
 * @desciption:
 */

public class ApiException {
}
