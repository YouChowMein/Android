package com.wuchao.latte.wechat.templates;

import com.wuchao.latte.activitys.ProxyActivity;
import com.wuchao.latte.delegates.LatteDelegate;

/**
 * @author: wuchao
 * @date: 2017/12/27 23:04
 * @desciption:
 */

public class AppRegisterTemplate extends ProxyActivity{
    @Override
    public LatteDelegate setRootDelegate() {
        return null;
    }
}
