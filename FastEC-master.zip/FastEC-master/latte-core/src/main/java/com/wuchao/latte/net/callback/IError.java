package com.wuchao.latte.net.callback;

/**
 * @author: wuchao
 * @date: 2017/10/23 23:08
 * @desciption:
 */

public interface IError {

    void onError(int code, String msg);
}
