package com.wuchao.latte.net.callback;

/**
 * @author: wuchao
 * @date: 2017/10/23 23:09
 * @desciption:
 */

public interface IFailure {

    void onFailure();
}
