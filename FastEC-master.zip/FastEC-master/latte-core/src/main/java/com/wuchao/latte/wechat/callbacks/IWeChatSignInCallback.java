package com.wuchao.latte.wechat.callbacks;

/**
 * @author: wuchao
 * @date: 2017/12/29 21:15
 * @desciption:
 */

public interface IWeChatSignInCallback {
    void onSignInSuccess(String userInfo);
}
