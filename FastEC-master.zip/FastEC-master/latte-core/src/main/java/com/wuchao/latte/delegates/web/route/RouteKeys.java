package com.wuchao.latte.delegates.web.route;

/**
 * @author: wuchao
 * @date: 2017/11/28 22:56
 * @desciption:
 */

public enum RouteKeys {
    /**
     * web页面跳转必须传递的参数
     */
    URL
}
