package com.wuchao.latte.delegates.web.event;

/**
 * @author: wuchao
 * @date: 2017/11/29 22:22
 * @desciption:
 */

public interface IEvent {
    String execute(String params);
}
