package com.wuchao.latte.app;

/**
 * @author: wuchao
 * @date: 2017/11/27 18:58
 * @desciption: 用户信息
 */

public interface IUserChecker {

    void onSignIn();

    void onNotSignIn();
}
