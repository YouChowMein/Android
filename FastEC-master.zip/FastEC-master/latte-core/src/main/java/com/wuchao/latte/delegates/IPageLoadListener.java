package com.wuchao.latte.delegates;

/**
 * @author: wuchao
 * @date: 2017/12/23 17:59
 * @desciption:
 */

public interface IPageLoadListener {

    void onLoadStart();

    void onLoadEnd();
}
