package com.wuchao.latte.ui.launcher;

/**
 * @author: wuchao
 * @date: 2017/11/16 22:15
 * @desciption:
 */

public enum ScrollLauncherTag {
    HAS_FIRST_LAUNCHER_APP
}
