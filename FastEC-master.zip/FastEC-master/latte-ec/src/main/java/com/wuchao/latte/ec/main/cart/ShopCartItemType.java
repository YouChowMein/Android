package com.wuchao.latte.ec.main.cart;

/**
 * @author: wuchao
 * @date: 2017/12/24 00:10
 * @desciption:
 */

class ShopCartItemType {
    static final int SHOP_CART_ITEM = 6;
}
