package com.wuchao.latte.ec.main.personal.address;

/**
 * @author: wuchao
 * @date: 2018/1/7 19:21
 * @desciption:
 */

public class AddressItemType {
    static final int ITEM_ADDRESS = 40;
}
