package com.wuchao.latte.ec.main.cart;

/**
 * @author: wuchao
 * @date: 2017/12/24 21:56
 * @desciption:
 */

public interface ICartItemListener {

    void onItemClick(double itemTotalPrice);
}
