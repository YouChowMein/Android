package com.wuchao.latte.ec.main.personal.order;

/**
 * @author: wuchao
 * @date: 2018/1/2 22:47
 * @desciption:
 */

public enum  OrderItemFields {
    PRICE,
    TIME
}
