package com.wuchao.latte.ec.main.personal.address;

/**
 * @author: wuchao
 * @date: 2018/1/7 19:20
 * @desciption:
 */

public enum AddressItemFields {
    PHONE,
    ADDRESS
}
