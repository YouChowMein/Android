package com.wuchao.latte.ec.launcher;

/**
 * @author: wuchao
 * @date: 2017/11/28 11:04
 * @desciption:
 */

public interface ILauncherListener {

    void onLauncherFinish(OnLauncherFinishTag tag);
}
