package com.wuchao.latte.ec.main.personal.order;

/**
 * @author: wuchao
 * @date: 2018/1/2 22:46
 * @desciption:
 */

public class OrderListItemType {
    public static final int ITEM_ORDER_LIST = 30;
}
