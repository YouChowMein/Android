package com.wuchao.latte.ec.main.personal.list;

/**
 * @author: wuchao
 * @date: 2018/1/2 22:40
 * @desciption:
 */

public class ListItemType {

    public static final int ITEM_NORMAL = 20;
    public static final int ITEM_AVATAR = 21;
    public static final int ITEM_SWITCH = 22;
}
