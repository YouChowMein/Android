package com.wuchao.latte.ec.main.index.search;

/**
 * @author: wuchao
 * @date: 2018/1/16 22:24
 * @desciption:
 */

public class SearchItemType {
    static final int ITEM_SEARCH = 50;
}
