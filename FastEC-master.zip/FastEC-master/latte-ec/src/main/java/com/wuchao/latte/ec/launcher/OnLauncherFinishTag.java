package com.wuchao.latte.ec.launcher;

/**
 * @author: wuchao
 * @date: 2017/11/28 11:03
 * @desciption:
 */

public enum  OnLauncherFinishTag {
    SIGNED,
    NOT_SIGNED
}
