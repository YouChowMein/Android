package com.wuchao.latte.ec.main.cart;

/**
 * @author: wuchao
 * @date: 2017/12/24 00:10
 * @desciption:
 */

public enum ShopCartItemFields {
    TITLE,
    DESC,
    COUNT,
    PRICE,
    IS_SELECTED,
    POSITION
}
