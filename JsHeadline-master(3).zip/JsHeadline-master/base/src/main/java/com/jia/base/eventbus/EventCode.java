package com.jia.base.eventbus;

/**
 * Description:定义统一的code，将来可做封装
 * Created by jia on 2018/3/27.
 * 人之所以能，是相信能。
 */

public class EventCode {

    public static final int A = 0x111111;
    public static final int B = 0x222222;
    public static final int C = 0x333333;
    public static final int D = 0x444444;

}
