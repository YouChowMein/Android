package com.mangosteen.headline.wxapi;

import com.elbbbird.android.socialsdk.sso.wechat.WXCallbackActivity;

/**
 * Description:
 * Created by jia on 2018/4/8.
 * 人之所以能，是相信能。
 */

public class WXEntryActivity extends WXCallbackActivity {

}
