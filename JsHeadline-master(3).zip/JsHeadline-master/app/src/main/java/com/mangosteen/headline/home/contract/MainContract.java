package com.mangosteen.headline.home.contract;

/**
 * Description:
 * Created by jia on 2018/3/28.
 * 人之所以能，是相信能。
 */

public class MainContract {

}
