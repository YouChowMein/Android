package com.jia.libnet.bean.video;

import java.util.List;

/**
 * Description:
 * Created by jia on 2018/6/8.
 * 人之所以能，是相信能。
 */

public class VideoCommentBean {


    /**
     * message : success
     * data : [{"comment":{"id":1602607158481924,"text":"和珅，你以为你穿西装我就认不出来是你吗？","content_rich_span":"{\"links\":[]}","reply_count":5,"reply_list":[],"digg_count":233,"bury_count":0,"forward_count":0,"create_time":1528365286,"score":0.6570910811424255,"user_id":16430167206,"user_name":"苏啊郎","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/75610007480d5546eb69","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602606817668099,"text":"我记得有一个老大爷好多年没有喝水还活的好好的  最后调查了两集发现每顿饭都喝一大碗汤","content_rich_span":"{\"links\":[]}","reply_count":9,"reply_list":[],"digg_count":300,"bury_count":0,"forward_count":0,"create_time":1528364961,"score":0.6270371079444885,"user_id":5512519002,"user_name":"开它娘的意大利炮","remark_name":"","user_profile_image_url":"http://q.qlogo.cn/qqapp/100290348/A8F69F84CE87A8FC5725CA65DB24EFB1/100","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602608168097799,"text":"专家还说 刚烧开的水，不能喝。因为烫嘴[鼾睡][鼾睡][鼾睡]","content_rich_span":"{\"links\":[]}","reply_count":5,"reply_list":[],"digg_count":121,"bury_count":0,"forward_count":0,"create_time":1528366249,"score":0.5375891923904419,"user_id":93109407452,"user_name":"北漂西行南迁的一一胡渣叔叔","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/65840053448646cdb29f","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602609515936782,"text":"王刚，问你个事，你是不是把人家古董当赝品，一锤子砸烂了？[抠鼻]","content_rich_span":"{\"links\":[]}","reply_count":2,"reply_list":[],"digg_count":98,"bury_count":0,"forward_count":0,"create_time":1528367535,"score":0.5260531902313232,"user_id":3242010247,"user_name":"阿福9541191","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/719c0018ea8d5c388ff2","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602606364800007,"text":"走进科学，天降奇冰包治百病，寻根究底飞机抛尿","content_rich_span":"{\"links\":[]}","reply_count":1,"reply_list":[],"digg_count":101,"bury_count":0,"forward_count":0,"create_time":1528364529,"score":0.49639296531677246,"user_id":51108475092,"user_name":"千叶御丸","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/e580009544fb1298135","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602608954570824,"text":"有文化真可怕，一个海狸鼠的故事，讲的这么神秘","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":59,"bury_count":0,"forward_count":0,"create_time":1528366999,"score":0.4794977605342865,"user_id":6477353453,"user_name":"手机用户6477353453","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/3e81001d2a0bdfff3f27","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602611069803614,"text":"有头无尾就别发出来了[捂脸]","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":11,"bury_count":0,"forward_count":0,"create_time":1528369017,"score":0.455476850271225,"user_id":6714430041,"user_name":"羅俊业","remark_name":"","user_profile_image_url":"http://p1.pstatp.com/thumb/2c6d000b0e14097707b7","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602620139798557,"text":"废话真多   还卖关子","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":5,"bury_count":0,"forward_count":0,"create_time":1528377666,"score":0.44742870330810547,"user_id":93192649215,"user_name":"自然风3655","remark_name":"","user_profile_image_url":"http://p1.pstatp.com/thumb/658700544f123532862d","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602608294047758,"text":"水獭可是国家二级重点保护动物，让国家赔偿[笑哭]","content_rich_span":"{\"links\":[]}","reply_count":2,"reply_list":[],"digg_count":51,"bury_count":0,"forward_count":0,"create_time":1528366369,"score":0.4410668611526489,"user_id":71029162871,"user_name":"留恋225014239","remark_name":"","user_profile_image_url":"http://p1.pstatp.com/thumb/3e7e0000f83f0cb73a48","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602613246386189,"text":"上次小编发视频发一半 结果小弟弟 被龙虾夹掉了，就流血过多而亡！走的不太安详！火烧的也不大旺，后来刨开大肠和下水 才烧干净","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":2,"bury_count":0,"forward_count":0,"create_time":1528371092,"score":0.4242163300514221,"user_id":6156474798,"user_name":"混了29年666","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/249b0017a95f59dbb188","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602618957531139,"text":"拿个买鱼苗的钱和买蟹苗的钱出去喝酒坐台去了？然后。把锅啊，甩给水獭。","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":1,"bury_count":0,"forward_count":0,"create_time":1528376539,"score":0.418041467666626,"user_id":60049515169,"user_name":"苶呆","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/216b000481eb5bf43d64","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602609065787396,"text":"我说声音怎么这么熟悉，原来是和大人您呐？","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":10,"bury_count":0,"forward_count":0,"create_time":1528367105,"score":0.3654493987560272,"user_id":58514637571,"user_name":"i176965529","remark_name":"","user_profile_image_url":"http://s0.pstatp.com/image/avatar.png","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602609789240327,"text":"专家讲用纸碗吃泡面不健康","content_rich_span":"{\"links\":[]}","reply_count":1,"reply_list":[],"digg_count":8,"bury_count":0,"forward_count":0,"create_time":1528367795,"score":0.3646778166294098,"user_id":81242728621,"user_name":"好想给你一个简单的","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/86000014b84411122706","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602605887495172,"text":"妈耶。他还敢用手去摸","content_rich_span":"{\"links\":[]}","reply_count":1,"reply_list":[],"digg_count":22,"bury_count":0,"forward_count":0,"create_time":1528364074,"score":0.36277300119400024,"user_id":15360388891,"user_name":"糊涂虫134569917","remark_name":"","user_profile_image_url":"http://p9.pstatp.com/thumb/5ac70007294e004ff4b6","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602610325462024,"text":"专家说拉完粑粑要擦屁股，不擦会很臭，有人不信，拉粑粑就不擦屁股，果不其然，专家没说错","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":6,"bury_count":0,"forward_count":0,"create_time":1528368307,"score":0.3531625270843506,"user_id":93009270568,"user_name":"恋梦梦578","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/7b99001ad2b26935a3f0","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602614431223815,"text":"发财了，一张水獭皮就值几万块","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":2,"bury_count":0,"forward_count":0,"create_time":1528372222,"score":0.34817931056022644,"user_id":65248612655,"user_name":"郑志明36","remark_name":"","user_profile_image_url":"http://p1.pstatp.com/thumb/2c6c001644e9dfbc3dd2","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602610330250244,"text":"有病吗。侮辱人类的智商.还水怪[大笑]","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":11,"bury_count":0,"forward_count":0,"create_time":1528368311,"score":0.34505629539489746,"user_id":15076452141,"user_name":"骄阳似我127809690","remark_name":"","user_profile_image_url":"http://p1.pstatp.com/thumb/96a001ecba457811529","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602622092589069,"text":"被和珅吃了[我想静静][我想静静][我想静静][我想静静]","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":0,"bury_count":0,"forward_count":0,"create_time":1528379529,"score":0.34491100907325745,"user_id":78797955194,"user_name":"樊泽友1853829","remark_name":"","user_profile_image_url":"http://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTJGvBKsQNGHUnptetgzznoANEQKXZBCYtPias3yZQmoJQiaCNXlXafPJica3amJb7giaPsgT0icsianLlcg/64","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602609357416451,"text":"纪晓岚，快来，和珅说胡话","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":9,"bury_count":0,"forward_count":0,"create_time":1528367383,"score":0.3420802652835846,"user_id":98184027737,"user_name":"李牧44246515","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/8349000570f71b2db5b3","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1},{"comment":{"id":1602609233844231,"text":"和坤，你又在吹牛逼了[微笑][微笑][微笑]","content_rich_span":"{\"links\":[]}","reply_count":0,"reply_list":[],"digg_count":6,"bury_count":0,"forward_count":0,"create_time":1528367266,"score":0.3409629762172699,"user_id":6027075463,"user_name":"1漂洋过海来看你","remark_name":"","user_profile_image_url":"http://p1.pstatp.com/thumb/1dcd000bfdc76cf381b8","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"},"cell_type":1}]
     * total_number : 118
     * has_more : true
     * fold_comment_count : 0
     * detail_no_comment : 0
     * ban_comment : false
     * ban_face : false
     * ban_pic_comment : 1
     * go_topic_detail : 1
     * show_add_forum : 1
     * stick_comments : []
     * stick_total_number : 0
     * stick_has_more : false
     * tab_info : {"current_tab_index":0,"tabs":["热度","时间"]}
     * group : {"user_id":84145485915,"user_name":"听王刚讲故事","is_video":true,"content":"","content_rich_span":""}
     * repost_params : {"fw_id":6564247046243484164,"fw_id_type":4,"fw_user_id":84145485915,"repost_type":211,"title":"养殖池塘里螃蟹出走鱼群失踪，水底发现神秘大洞，真凶原来是它！","cover_url":"http://p1.pstatp.com/list/300x300/pgc-image/152835764514171b76a552b","schema":""}
     * stable : true
     */

    private String message;
    private int total_number;
    private boolean has_more;
    private int fold_comment_count;
    private int detail_no_comment;
    private boolean ban_comment;
    private boolean ban_face;
    private int ban_pic_comment;
    private int go_topic_detail;
    private int show_add_forum;
    private int stick_total_number;
    private boolean stick_has_more;
    private TabInfoEntity tab_info;
    private GroupEntity group;
    private RepostParamsEntity repost_params;
    private boolean stable;
    private List<DataEntity> data;
    private List<?> stick_comments;

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public int getTotal_number() {
        return total_number;
    }

    public void setTotal_number(int total_number) {
        this.total_number = total_number;
    }

    public boolean isHas_more() {
        return has_more;
    }

    public void setHas_more(boolean has_more) {
        this.has_more = has_more;
    }

    public int getFold_comment_count() {
        return fold_comment_count;
    }

    public void setFold_comment_count(int fold_comment_count) {
        this.fold_comment_count = fold_comment_count;
    }

    public int getDetail_no_comment() {
        return detail_no_comment;
    }

    public void setDetail_no_comment(int detail_no_comment) {
        this.detail_no_comment = detail_no_comment;
    }

    public boolean isBan_comment() {
        return ban_comment;
    }

    public void setBan_comment(boolean ban_comment) {
        this.ban_comment = ban_comment;
    }

    public boolean isBan_face() {
        return ban_face;
    }

    public void setBan_face(boolean ban_face) {
        this.ban_face = ban_face;
    }

    public int getBan_pic_comment() {
        return ban_pic_comment;
    }

    public void setBan_pic_comment(int ban_pic_comment) {
        this.ban_pic_comment = ban_pic_comment;
    }

    public int getGo_topic_detail() {
        return go_topic_detail;
    }

    public void setGo_topic_detail(int go_topic_detail) {
        this.go_topic_detail = go_topic_detail;
    }

    public int getShow_add_forum() {
        return show_add_forum;
    }

    public void setShow_add_forum(int show_add_forum) {
        this.show_add_forum = show_add_forum;
    }

    public int getStick_total_number() {
        return stick_total_number;
    }

    public void setStick_total_number(int stick_total_number) {
        this.stick_total_number = stick_total_number;
    }

    public boolean isStick_has_more() {
        return stick_has_more;
    }

    public void setStick_has_more(boolean stick_has_more) {
        this.stick_has_more = stick_has_more;
    }

    public TabInfoEntity getTab_info() {
        return tab_info;
    }

    public void setTab_info(TabInfoEntity tab_info) {
        this.tab_info = tab_info;
    }

    public GroupEntity getGroup() {
        return group;
    }

    public void setGroup(GroupEntity group) {
        this.group = group;
    }

    public RepostParamsEntity getRepost_params() {
        return repost_params;
    }

    public void setRepost_params(RepostParamsEntity repost_params) {
        this.repost_params = repost_params;
    }

    public boolean isStable() {
        return stable;
    }

    public void setStable(boolean stable) {
        this.stable = stable;
    }

    public List<DataEntity> getData() {
        return data;
    }

    public void setData(List<DataEntity> data) {
        this.data = data;
    }

    public List<?> getStick_comments() {
        return stick_comments;
    }

    public void setStick_comments(List<?> stick_comments) {
        this.stick_comments = stick_comments;
    }

    public static class TabInfoEntity {
        /**
         * current_tab_index : 0
         * tabs : ["热度","时间"]
         */

        private int current_tab_index;
        private List<String> tabs;

        public int getCurrent_tab_index() {
            return current_tab_index;
        }

        public void setCurrent_tab_index(int current_tab_index) {
            this.current_tab_index = current_tab_index;
        }

        public List<String> getTabs() {
            return tabs;
        }

        public void setTabs(List<String> tabs) {
            this.tabs = tabs;
        }
    }

    public static class GroupEntity {
        /**
         * user_id : 84145485915
         * user_name : 听王刚讲故事
         * is_video : true
         * content :
         * content_rich_span :
         */

        private long user_id;
        private String user_name;
        private boolean is_video;
        private String content;
        private String content_rich_span;

        public long getUser_id() {
            return user_id;
        }

        public void setUser_id(long user_id) {
            this.user_id = user_id;
        }

        public String getUser_name() {
            return user_name;
        }

        public void setUser_name(String user_name) {
            this.user_name = user_name;
        }

        public boolean isIs_video() {
            return is_video;
        }

        public void setIs_video(boolean is_video) {
            this.is_video = is_video;
        }

        public String getContent() {
            return content;
        }

        public void setContent(String content) {
            this.content = content;
        }

        public String getContent_rich_span() {
            return content_rich_span;
        }

        public void setContent_rich_span(String content_rich_span) {
            this.content_rich_span = content_rich_span;
        }
    }

    public static class RepostParamsEntity {
        /**
         * fw_id : 6564247046243484164
         * fw_id_type : 4
         * fw_user_id : 84145485915
         * repost_type : 211
         * title : 养殖池塘里螃蟹出走鱼群失踪，水底发现神秘大洞，真凶原来是它！
         * cover_url : http://p1.pstatp.com/list/300x300/pgc-image/152835764514171b76a552b
         * schema :
         */

        private long fw_id;
        private int fw_id_type;
        private long fw_user_id;
        private int repost_type;
        private String title;
        private String cover_url;
        private String schema;

        public long getFw_id() {
            return fw_id;
        }

        public void setFw_id(long fw_id) {
            this.fw_id = fw_id;
        }

        public int getFw_id_type() {
            return fw_id_type;
        }

        public void setFw_id_type(int fw_id_type) {
            this.fw_id_type = fw_id_type;
        }

        public long getFw_user_id() {
            return fw_user_id;
        }

        public void setFw_user_id(long fw_user_id) {
            this.fw_user_id = fw_user_id;
        }

        public int getRepost_type() {
            return repost_type;
        }

        public void setRepost_type(int repost_type) {
            this.repost_type = repost_type;
        }

        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getCover_url() {
            return cover_url;
        }

        public void setCover_url(String cover_url) {
            this.cover_url = cover_url;
        }

        public String getSchema() {
            return schema;
        }

        public void setSchema(String schema) {
            this.schema = schema;
        }
    }

    public static class DataEntity {
        /**
         * comment : {"id":1602607158481924,"text":"和珅，你以为你穿西装我就认不出来是你吗？","content_rich_span":"{\"links\":[]}","reply_count":5,"reply_list":[],"digg_count":233,"bury_count":0,"forward_count":0,"create_time":1528365286,"score":0.6570910811424255,"user_id":16430167206,"user_name":"苏啊郎","remark_name":"","user_profile_image_url":"http://p3.pstatp.com/thumb/75610007480d5546eb69","user_verified":false,"is_following":0,"is_followed":0,"is_blocking":0,"is_blocked":0,"is_pgc_author":0,"author_badge":[],"verified_reason":"","user_bury":0,"user_digg":0,"user_relation":0,"user_auth_info":"","user_decoration":"","large_image_list":null,"thumb_image_list":null,"media_info":{"name":"","avatar_url":""},"platform":"feifei"}
         * cell_type : 1
         */

        private CommentEntity comment;
        private int cell_type;

        public CommentEntity getComment() {
            return comment;
        }

        public void setComment(CommentEntity comment) {
            this.comment = comment;
        }

        public int getCell_type() {
            return cell_type;
        }

        public void setCell_type(int cell_type) {
            this.cell_type = cell_type;
        }

        public static class CommentEntity {
            /**
             * id : 1602607158481924
             * text : 和珅，你以为你穿西装我就认不出来是你吗？
             * content_rich_span : {"links":[]}
             * reply_count : 5
             * reply_list : []
             * digg_count : 233
             * bury_count : 0
             * forward_count : 0
             * create_time : 1528365286
             * score : 0.6570910811424255
             * user_id : 16430167206
             * user_name : 苏啊郎
             * remark_name :
             * user_profile_image_url : http://p3.pstatp.com/thumb/75610007480d5546eb69
             * user_verified : false
             * is_following : 0
             * is_followed : 0
             * is_blocking : 0
             * is_blocked : 0
             * is_pgc_author : 0
             * author_badge : []
             * verified_reason :
             * user_bury : 0
             * user_digg : 0
             * user_relation : 0
             * user_auth_info :
             * user_decoration :
             * large_image_list : null
             * thumb_image_list : null
             * media_info : {"name":"","avatar_url":""}
             * platform : feifei
             */

            private long id;
            private String text;
            private String content_rich_span;
            private int reply_count;
            private int digg_count;
            private int bury_count;
            private int forward_count;
            private int create_time;
            private double score;
            private long user_id;
            private String user_name;
            private String remark_name;
            private String user_profile_image_url;
            private boolean user_verified;
            private int is_following;
            private int is_followed;
            private int is_blocking;
            private int is_blocked;
            private int is_pgc_author;
            private String verified_reason;
            private int user_bury;
            private int user_digg;
            private int user_relation;
            private String user_auth_info;
            private String user_decoration;
            private Object large_image_list;
            private Object thumb_image_list;
            private MediaInfoEntity media_info;
            private String platform;
            private List<?> reply_list;
            private List<?> author_badge;

            public long getId() {
                return id;
            }

            public void setId(long id) {
                this.id = id;
            }

            public String getText() {
                return text;
            }

            public void setText(String text) {
                this.text = text;
            }

            public String getContent_rich_span() {
                return content_rich_span;
            }

            public void setContent_rich_span(String content_rich_span) {
                this.content_rich_span = content_rich_span;
            }

            public int getReply_count() {
                return reply_count;
            }

            public void setReply_count(int reply_count) {
                this.reply_count = reply_count;
            }

            public int getDigg_count() {
                return digg_count;
            }

            public void setDigg_count(int digg_count) {
                this.digg_count = digg_count;
            }

            public int getBury_count() {
                return bury_count;
            }

            public void setBury_count(int bury_count) {
                this.bury_count = bury_count;
            }

            public int getForward_count() {
                return forward_count;
            }

            public void setForward_count(int forward_count) {
                this.forward_count = forward_count;
            }

            public int getCreate_time() {
                return create_time;
            }

            public void setCreate_time(int create_time) {
                this.create_time = create_time;
            }

            public double getScore() {
                return score;
            }

            public void setScore(double score) {
                this.score = score;
            }

            public long getUser_id() {
                return user_id;
            }

            public void setUser_id(long user_id) {
                this.user_id = user_id;
            }

            public String getUser_name() {
                return user_name;
            }

            public void setUser_name(String user_name) {
                this.user_name = user_name;
            }

            public String getRemark_name() {
                return remark_name;
            }

            public void setRemark_name(String remark_name) {
                this.remark_name = remark_name;
            }

            public String getUser_profile_image_url() {
                return user_profile_image_url;
            }

            public void setUser_profile_image_url(String user_profile_image_url) {
                this.user_profile_image_url = user_profile_image_url;
            }

            public boolean isUser_verified() {
                return user_verified;
            }

            public void setUser_verified(boolean user_verified) {
                this.user_verified = user_verified;
            }

            public int getIs_following() {
                return is_following;
            }

            public void setIs_following(int is_following) {
                this.is_following = is_following;
            }

            public int getIs_followed() {
                return is_followed;
            }

            public void setIs_followed(int is_followed) {
                this.is_followed = is_followed;
            }

            public int getIs_blocking() {
                return is_blocking;
            }

            public void setIs_blocking(int is_blocking) {
                this.is_blocking = is_blocking;
            }

            public int getIs_blocked() {
                return is_blocked;
            }

            public void setIs_blocked(int is_blocked) {
                this.is_blocked = is_blocked;
            }

            public int getIs_pgc_author() {
                return is_pgc_author;
            }

            public void setIs_pgc_author(int is_pgc_author) {
                this.is_pgc_author = is_pgc_author;
            }

            public String getVerified_reason() {
                return verified_reason;
            }

            public void setVerified_reason(String verified_reason) {
                this.verified_reason = verified_reason;
            }

            public int getUser_bury() {
                return user_bury;
            }

            public void setUser_bury(int user_bury) {
                this.user_bury = user_bury;
            }

            public int getUser_digg() {
                return user_digg;
            }

            public void setUser_digg(int user_digg) {
                this.user_digg = user_digg;
            }

            public int getUser_relation() {
                return user_relation;
            }

            public void setUser_relation(int user_relation) {
                this.user_relation = user_relation;
            }

            public String getUser_auth_info() {
                return user_auth_info;
            }

            public void setUser_auth_info(String user_auth_info) {
                this.user_auth_info = user_auth_info;
            }

            public String getUser_decoration() {
                return user_decoration;
            }

            public void setUser_decoration(String user_decoration) {
                this.user_decoration = user_decoration;
            }

            public Object getLarge_image_list() {
                return large_image_list;
            }

            public void setLarge_image_list(Object large_image_list) {
                this.large_image_list = large_image_list;
            }

            public Object getThumb_image_list() {
                return thumb_image_list;
            }

            public void setThumb_image_list(Object thumb_image_list) {
                this.thumb_image_list = thumb_image_list;
            }

            public MediaInfoEntity getMedia_info() {
                return media_info;
            }

            public void setMedia_info(MediaInfoEntity media_info) {
                this.media_info = media_info;
            }

            public String getPlatform() {
                return platform;
            }

            public void setPlatform(String platform) {
                this.platform = platform;
            }

            public List<?> getReply_list() {
                return reply_list;
            }

            public void setReply_list(List<?> reply_list) {
                this.reply_list = reply_list;
            }

            public List<?> getAuthor_badge() {
                return author_badge;
            }

            public void setAuthor_badge(List<?> author_badge) {
                this.author_badge = author_badge;
            }

            public static class MediaInfoEntity {
                /**
                 * name :
                 * avatar_url :
                 */

                private String name;
                private String avatar_url;

                public String getName() {
                    return name;
                }

                public void setName(String name) {
                    this.name = name;
                }

                public String getAvatar_url() {
                    return avatar_url;
                }

                public void setAvatar_url(String avatar_url) {
                    this.avatar_url = avatar_url;
                }
            }
        }
    }
}
