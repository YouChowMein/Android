package com.jia.libnet;

/**
 * Describtion:url配置类
 * Created by jia on 2017/6/6.
 * 人之所以能，是相信能
 */
public class NetConfig {

    /**
     * base url
     */
    public static String BASE_URL = "http://m.toutiao.com/";

}
